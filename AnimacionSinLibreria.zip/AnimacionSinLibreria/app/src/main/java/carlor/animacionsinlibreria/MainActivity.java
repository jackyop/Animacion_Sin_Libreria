package carlor.animacionsinlibreria;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    private static final int FRAME_W = 85;
    private static final int FRAME_H = 121;
    private static final int NB_FRAMES = 14;
    private static final int COUNT_X = 5;
    private static final int COUNT_Y = 3;
    private static final int FRAME_DURATION = 200; // ms
    private static final int SCALE_FACTOR = 3;
    private static final int frame_w2=27;
    private static final int frame_h2 = 38;
    private static final int nb_frames2 = 7;
    private static final int count_x2 = 7;
    private static final int count_y2 = 1;
    private static final int frame_w3= 72;
    private static final int frame_h3 =100;
    private static final int nb_frames3 = 5;
    private static final int count_x3 = 5;
    private static final int count_y3 = 1;
    private ImageView img;
    private ImageView img2;
    private ImageView img3;
    private Bitmap[] bmps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = (ImageView) findViewById(R.id.img);
        img2 = (ImageView) findViewById(R.id.img2);
        img3 = (ImageView) findViewById(R.id.img3);
        Bitmap birdBmp = getBitmapFromAssets(this, "img1.png");
        Bitmap agumon = getBitmapFromAssets(this, "img2.png");
        Bitmap dragon = getBitmapFromAssets(this, "img3.png");

        if (birdBmp != null) {
            animacion(FRAME_W,FRAME_H,NB_FRAMES,COUNT_X,COUNT_Y,SCALE_FACTOR,birdBmp,img);
            animacion(frame_w2,frame_h2,nb_frames2,count_x2,count_y2,SCALE_FACTOR*3,agumon,img2);
            animacion(frame_w3,frame_h3,nb_frames3,count_x3,count_y3,SCALE_FACTOR*2,dragon,img3);
        }
    }
    private void animacion(int framew,int frameh,int nframes,int contx,int conty,int scale,Bitmap bitmap,ImageView img){
        bmps = new Bitmap[nframes];
        int currentFrame = 0;

        for (int i = 0; i < conty; i++) {
            for (int j = 0; j < contx; j++) {
                bmps[currentFrame] = Bitmap.createBitmap(bitmap, framew
                        * j, frameh * i, framew, frameh);
                bmps[currentFrame] = Bitmap.createScaledBitmap(
                        bmps[currentFrame], framew * scale, frameh * scale, true);
                currentFrame = currentFrame+1;
                if (currentFrame >= nframes) {
                    break;
                }
            }
        }
        final AnimationDrawable animation = new AnimationDrawable();
        animation.setOneShot(false); // repetir animacion
        for (int i = 0; i < nframes; i++) {
            animation.addFrame(new BitmapDrawable(getResources(), bmps[i]),
                    FRAME_DURATION);
        }
        if (Build.VERSION.SDK_INT < 16) {
            img.setBackgroundDrawable(animation);
        } else {
            img.setBackground(animation);
        }
        img.post(new Runnable() {

            @Override
            public void run() {
                animation.start();
            }

        });
    }

    private Bitmap getBitmapFromAssets(MainActivity mainActivity, String filepath) {
        AssetManager assetManager = mainActivity.getAssets();
        InputStream istr = null;
        Bitmap bitmap = null;

        try {
            istr = assetManager.open(filepath);
            bitmap = BitmapFactory.decodeStream(istr);
        } catch (IOException ioe) {
            // manage exception
        } finally {
            if (istr != null) {
                try {
                    istr.close();
                } catch (IOException e) {
                }
            }
        }

        return bitmap;
    }
}
